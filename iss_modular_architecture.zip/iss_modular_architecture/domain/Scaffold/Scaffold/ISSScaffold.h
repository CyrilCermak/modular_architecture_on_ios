//
//  Scaffold.h
//  Scaffold
//
//  Created by Cyril Cermak on 04.01.21.
//

#import <Foundation/Foundation.h>

//! Project version number for Template.
FOUNDATION_EXPORT double ISSScaffoldVersionNumber;

//! Project version string for Template.
FOUNDATION_EXPORT const unsigned char ISSScaffoldVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Template/PublicHeader.h>


