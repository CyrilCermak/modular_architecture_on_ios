//
//  OverviewService.h
//  OverviewService
//
//  Created by Cyril Cermak on 04.01.21.
//

#import <Foundation/Foundation.h>

//! Project version number for Template.
FOUNDATION_EXPORT double ISSOverviewServiceVersionNumber;

//! Project version string for Template.
FOUNDATION_EXPORT const unsigned char ISSOverviewServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Template/PublicHeader.h>


